# DTC Raid Tracker

## [v6.8.0](https://github.com/Voltrizzy/DTC_RaidTracker/tree/v6.8.0) (2026-01-28)
[Full Changelog](https://github.com/Voltrizzy/DTC_RaidTracker/compare/v6.4.1.1...v6.8.0) 

- Update README.md  
- Update DTC\_RaidTracker.toc  
- Update DisneyTripWorker.lua  
    big updates  